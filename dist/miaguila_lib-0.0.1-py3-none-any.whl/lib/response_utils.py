"""
Configuration of http responses
"""

from fastapi.exceptions import HTTPException
from fastapi.responses import JSONResponse
from fastapi import status
from fastapi.encoders import jsonable_encoder

from config.internal_errors import INTERNAL_ERRORS

def json_response(data=None, message=None, http_status=status.HTTP_200_OK):
    """
    Return JSON
    """
    content = dict(
        data=jsonable_encoder(data),
        message=message,
        success=True,
        http_status=http_status
    )
    return JSONResponse(status_code=http_status, content=content)


def json_error_response(error_key):
    """
    Return an error
    """
    error_ = _get_error_data(error_key)
    return HTTPException(
        status_code=error_['http_status'],
        detail={ **error_, **dict(success=False)}
    )

def _get_error_data(error_string):
    err_entity, err_content = error_string.split('.')
    return INTERNAL_ERRORS[err_entity][err_content]
