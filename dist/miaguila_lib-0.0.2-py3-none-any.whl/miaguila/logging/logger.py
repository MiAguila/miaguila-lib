"""
Logging to New Relic
"""
import json

import requests

from miaguila.config.settings import settings

class Logger:
    def __init__(self):
        self.log_url = settings.logger.new_relic_url

    def log(self, message: str, data: dict) -> None:
        # TO DO: batch logs, handle error levels, make async
        data['message'] = message
        log_to_send = json.dumps([data])
        requests.post(
            self.log_url,
            data=log_to_send
        )

logger = Logger()
